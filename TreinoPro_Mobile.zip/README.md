# TreinoPro — aplicativo mobile
Projeto Expo/React Native para Android e iOS.

## Rodar
1. Instale Node.js.
2. Na pasta do projeto, rode `npm install`.
3. Rode `npx expo start`.
4. Use Expo Go no celular ou um emulador Android/iOS.

O projeto já possui navegação, treinos, execução de exercícios, perfil, evolução e painel de personal. Para produção, conectar autenticação, banco de dados, armazenamento de vídeos e notificações push.
