import React, {useState} from 'react';
import {SafeAreaView, View, Text, TouchableOpacity, ScrollView, StyleSheet, TextInput} from 'react-native';
import {StatusBar} from 'expo-status-bar';

const exercises = [
  ['🏋️','Supino reto','4 séries × 10','80 kg'],
  ['💪','Supino inclinado','3 séries × 12','30 kg'],
  ['🦾','Tríceps pulley','3 séries × 12','45 kg'],
];

export default function App(){
  const [tab,setTab]=useState('Início');
  const [training,setTraining]=useState(false);
  const [done,setDone]=useState({});
  const [name,setName]=useState('Meu nome');

  const nav = ['Início','Treinos','Evolução','Personal','Perfil'];

  return <SafeAreaView style={s.safe}>
    <StatusBar style="light"/>
    <View style={s.header}><Text style={s.logo}>TREINO<Text style={{color:'#e9c84a'}}>PRO</Text></Text><View style={s.avatar}><Text>👤</Text></View></View>

    <ScrollView style={s.body} contentContainerStyle={{paddingBottom:100}}>
      {tab==='Início' && <>
        <Text style={s.muted}>Olá, atleta 👋</Text><Text style={s.title}>Treino de hoje</Text>
        <View style={s.hero}><Text style={s.tag}>TREINO A</Text><Text style={s.heroTitle}>Peito + Tríceps</Text><Text style={s.muted}>7 exercícios · 55 min · Hipertrofia</Text>
          <TouchableOpacity style={s.primary} onPress={()=>setTraining(true)}><Text style={s.primaryText}>Começar treino</Text></TouchableOpacity>
        </View>
        <View style={s.row}><View style={s.stat}><Text style={s.big}>4/5</Text><Text style={s.muted}>treinos/semana</Text></View><View style={s.stat}><Text style={s.big}>12</Text><Text style={s.muted}>dias de sequência</Text></View></View>
        <Text style={s.section}>Próximo exercício</Text><View style={s.card}><Text style={s.exerciseIcon}>🏋️</Text><View><Text style={s.bold}>Supino reto</Text><Text style={s.muted}>4 × 10 · 80 kg</Text></View></View>
      </>}

      {tab==='Treinos' && <><Text style={s.title}>Meus treinos</Text>{[['A','Peito + Tríceps','7 exercícios · 55 min'],['B','Costas + Bíceps','8 exercícios · 60 min'],['C','Pernas','9 exercícios · 65 min'],['D','Ombros + Abdômen','6 exercícios · 45 min']].map(x=>
        <View style={s.card} key={x[0]}><View style={s.row}><View><Text style={s.tag}>{x[0]}</Text><Text style={s.bold}>{x[1]}</Text><Text style={s.muted}>{x[2]}</Text></View><TouchableOpacity style={s.smallBtn} onPress={()=>setTraining(true)}><Text style={s.smallText}>Iniciar</Text></TouchableOpacity></View></View>)}</>}

      {tab==='Evolução' && <><Text style={s.title}>Minha evolução</Text><View style={s.row}><View style={s.stat}><Text style={s.big}>82 kg</Text><Text style={s.muted}>peso atual</Text></View><View style={s.stat}><Text style={s.big}>90 kg</Text><Text style={s.muted}>recorde supino</Text></View></View>
        <View style={s.card}><Text style={s.bold}>Consistência</Text><Text style={s.muted}>Últimas 8 semanas</Text><View style={s.bar}><View style={s.barFill}/></View><Text style={s.muted}>82% dos treinos concluídos.</Text></View>
        {['Supino reto — 90 kg','Agachamento — 120 kg','Levantamento terra — 140 kg'].map(t=><View style={s.card} key={t}><Text style={s.bold}>{t}</Text></View>)}</>}

      {tab==='Personal' && <><Text style={s.muted}>Painel do profissional</Text><Text style={s.title}>Meus alunos</Text>{['João Silva','Rafael Souza','Lucas Oliveira'].map((x,i)=><View style={s.card} key={x}><Text style={s.bold}>{x}</Text><Text style={s.muted}>Treino {String.fromCharCode(65+i)} · {82+i*4}% frequência</Text></View>)}<TouchableOpacity style={s.primary}><Text style={s.primaryText}>+ Cadastrar aluno</Text></TouchableOpacity></>}

      {tab==='Perfil' && <><Text style={s.title}>Meu perfil</Text><View style={s.card}><Text style={s.muted}>Nome</Text><TextInput value={name} onChangeText={setName} style={s.input}/><Text style={s.muted}>Objetivo</Text><TextInput value="Hipertrofia" style={s.input}/><Text style={s.muted}>Peso</Text><TextInput value="82 kg" style={s.input}/><TouchableOpacity style={s.primary}><Text style={s.primaryText}>Salvar alterações</Text></TouchableOpacity></View></>}
    </ScrollView>

    <View style={s.nav}>{nav.map(n=><TouchableOpacity key={n} onPress={()=>setTab(n)} style={s.navBtn}><Text style={[s.navIcon,{color:tab===n?'#e9c84a':'#777'}]}>{n==='Início'?'⌂':n==='Treinos'?'🏋️':n==='Evolução'?'📈':n==='Personal'?'👨‍🏫':'👤'}</Text><Text style={{fontSize:10,color:tab===n?'#e9c84a':'#777'}}>{n}</Text></TouchableOpacity>)}</View>

    {training && <View style={s.overlay}><View style={s.sheet}><View style={s.row}><Text style={s.sheetTitle}>Treino A</Text><TouchableOpacity onPress={()=>setTraining(false)}><Text style={s.close}>✕</Text></TouchableOpacity></View>
      {exercises.map((e,i)=><View style={s.exercise} key={e[1]}><Text style={s.exerciseIcon}>{e[0]}</Text><View style={{flex:1}}><Text style={s.bold}>{e[1]}</Text><Text style={s.muted}>{e[2]} · {e[3]}</Text></View><TouchableOpacity onPress={()=>setDone({...done,[i]:!done[i]})} style={[s.check,done[i]&&s.checked]}><Text>✓</Text></TouchableOpacity></View>)}
      <TouchableOpacity style={s.primary} onPress={()=>setTraining(false)}><Text style={s.primaryText}>Finalizar treino</Text></TouchableOpacity>
    </View></View>}
  </SafeAreaView>
}

const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#0b0b0c'},header:{height:68,paddingHorizontal:20,flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderBottomWidth:1,borderBottomColor:'#29292d'},logo:{fontSize:21,fontWeight:'900',color:'#fff'},avatar:{width:40,height:40,borderRadius:20,backgroundColor:'#26262a',alignItems:'center',justifyContent:'center'},body:{padding:20},muted:{color:'#9d9da2',fontSize:13,marginTop:3},title:{fontSize:29,fontWeight:'900',color:'#fff',marginBottom:18},hero:{backgroundColor:'#25231a',padding:18,borderRadius:19,marginBottom:12},heroTitle:{fontSize:24,fontWeight:'900',color:'#fff',marginVertical:8},tag:{alignSelf:'flex-start',color:'#e9c84a',backgroundColor:'#302b17',paddingHorizontal:9,paddingVertical:6,borderRadius:9,fontWeight:'900',fontSize:11,overflow:'hidden'},primary:{backgroundColor:'#e9c84a',padding:14,borderRadius:12,alignItems:'center',marginTop:15},primaryText:{color:'#111',fontWeight:'900'},row:{flexDirection:'row',gap:10},stat:{flex:1,backgroundColor:'#1c1c1f',padding:14,borderRadius:15},big:{fontSize:21,fontWeight:'900',color:'#fff'},section:{fontSize:18,fontWeight:'800',color:'#fff',marginTop:22,marginBottom:10},card:{backgroundColor:'#1c1c1f',borderWidth:1,borderColor:'#2a2a2e',borderRadius:18,padding:16,marginBottom:11},bold:{fontSize:15,fontWeight:'800',color:'#fff',marginBottom:4},exerciseIcon:{fontSize:25,marginRight:12},smallBtn:{backgroundColor:'#e9c84a',paddingVertical:11,paddingHorizontal:14,borderRadius:11},smallText:{fontWeight:'900',color:'#111'},bar:{height:8,backgroundColor:'#2b2b2f',borderRadius:8,marginVertical:12,overflow:'hidden'},barFill:{width:'82%',height:8,backgroundColor:'#e9c84a'},input:{backgroundColor:'#242427',borderColor:'#36363a',borderWidth:1,borderRadius:11,padding:12,color:'#fff',marginVertical:6,marginBottom:12},nav:{position:'absolute',bottom:0,left:0,right:0,height:72,backgroundColor:'#171719',borderTopWidth:1,borderTopColor:'#29292d',flexDirection:'row'},navBtn:{flex:1,alignItems:'center',justifyContent:'center'},navIcon:{fontSize:19,marginBottom:3},overlay:{position:'absolute',inset:0,backgroundColor:'#000c',justifyContent:'flex-end'},sheet:{backgroundColor:'#18181a',padding:20,borderTopLeftRadius:25,borderTopRightRadius:25},sheetTitle:{fontSize:23,fontWeight:'900',color:'#fff'},close:{fontSize:20,color:'#fff'},exercise:{flexDirection:'row',alignItems:'center',backgroundColor:'#222225',padding:12,borderRadius:14,marginVertical:5},check:{width:29,height:29,borderRadius:15,borderWidth:1,borderColor:'#555',alignItems:'center',justifyContent:'center'},checked:{backgroundColor:'#e9c84a',borderColor:'#e9c84a'}
})
